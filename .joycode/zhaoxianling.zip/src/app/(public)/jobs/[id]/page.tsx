"use client";

import { useEffect, useState } from "react";
import { useParams } from "next/navigation";
import Link from "next/link";

import type { Job } from "@/lib/types";
import {
  DOMAIN_LABELS,
  EMPLOYMENT_TYPE_LABELS,
} from "@/lib/constants";
import { useAuth } from "@/hooks/useAuth";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/Card";
import { Badge } from "@/components/ui/Badge";
import { Button } from "@/components/ui/Button";
import { LoadingSpinner } from "@/components/ui/LoadingSpinner";
import { ArrowLeft, UserPlus } from "lucide-react";

function getSalaryUnit(employmentType: Job["employment_type"]): string {
  switch (employmentType) {
    case "hourly":
      return "时";
    case "daily":
      return "日";
    case "fulltime":
      return "月";
    case "outsource":
      return "项目";
  }
}

export default function JobDetailPage() {
  const { id } = useParams<{ id: string }>();
  const { roles } = useAuth();
  const [job, setJob] = useState<Job | null>(null);
  const [loading, setLoading] = useState(true);

  const isReferrer = roles?.includes("referrer");

  useEffect(() => {
    async function fetchJob() {
      if (!id) {
        setLoading(false);
        return;
      }

      try {
        const response = await fetch(`/api/test-supabase?id=${id}`);
        const result = await response.json();

        if (result.success && result.data) {
          setJob(result.data as Job);
        }
      } catch (err) {
        console.error("[API] Error fetching job:", err);
      } finally {
        setLoading(false);
      }
    }

    fetchJob();
  }, [id]);

  if (loading) {
    return (
      <div className="container mx-auto p-6">
        <LoadingSpinner size="lg" label="加载中..." className="py-20" />
      </div>
    );
  }

  if (!job) {
    return (
      <div className="container mx-auto p-6">
        <div className="text-center py-20">
          <p className="text-gray-500">岗位不存在或已删除</p>
          <Link href="/" className="mt-4 inline-flex items-center text-brand-green">
            <ArrowLeft className="mr-1 h-4 w-4" />
            返回首页
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="container mx-auto p-6 max-w-2xl">
      <Link href="/" className="mb-4 inline-flex items-center text-muted-foreground hover:text-brand-green transition-colors">
        <ArrowLeft className="mr-1 h-4 w-4" />
        返回岗位列表
      </Link>

      <Card>
        <CardHeader>
          <CardTitle className="text-2xl">{job.title}</CardTitle>
          <div className="flex flex-wrap gap-2 mt-2">
            <Badge variant="brand-green">
              {EMPLOYMENT_TYPE_LABELS[job.employment_type]}
            </Badge>
            <Badge variant="muted">
              {DOMAIN_LABELS[job.domain]}
            </Badge>
            {job.is_active && (
              <Badge variant="brand-green">招聘中</Badge>
            )}
          </div>
        </CardHeader>
        <CardContent>
          <div className="space-y-6">
            <div>
              <h3 className="font-semibold text-base mb-2 text-foreground">
                工作地点
              </h3>
              <p className="text-gray-700">{job.location}</p>
            </div>

            <div>
              <h3 className="font-semibold text-base mb-2 text-foreground">
                薪资待遇
              </h3>
              {job.salary_min != null && job.salary_max != null && (
                <p className="text-xl font-bold text-brand-orange">
                  ¥{job.salary_min} - ¥{job.salary_max}
                  <span className="text-sm font-normal text-gray-600">
                    /{job.salary_unit || getSalaryUnit(job.employment_type)}
                  </span>
                </p>
              )}
            </div>

            <div>
              <h3 className="font-semibold text-base mb-2 text-foreground">
                岗位描述
              </h3>
              <p className="text-gray-700 whitespace-pre-wrap">
                {job.description}
              </p>
            </div>

            {job.requirements && (
              <div>
                <h3 className="font-semibold text-base mb-2 text-foreground">
                  任职要求
                </h3>
                <p className="text-gray-700 whitespace-pre-wrap">
                  {job.requirements}
                </p>
              </div>
            )}

            <div className="pt-4 border-t space-y-3">
              <Link href={`/jobs/${job.id}/apply`}>
                <Button size="lg" variant="primary" className="w-full">
                  立即投递
                </Button>
              </Link>
              {isReferrer && (
                <Link href={`/jobs/${job.id}/apply?mode=refer`}>
                  <Button size="lg" variant="outline" className="w-full">
                    <UserPlus className="mr-2" size={18} />
                    推荐候选人
                  </Button>
                </Link>
              )}
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
